####This script will plot everything
args = commandArgs(trailingOnly=TRUE)
if (length(args)<1) {
  stop("Please provide arguments like Rscript fig_3a_plotter.r input_3a.txt [input file should have: clade,gene,species,rpt,unalnstart,unalnend,alnstart,alnend,alnlength ", call.=FALSE)
}
library(stringr)
a1=read.table(args[1])
colnames(a1)=c("clade","gene","species","rpt","unalnstart","unalnend","alnstart","alnend","alnlength")
colpal=data.frame(aa = c("A","B","C","D","E","F","G","H","I","K","L","M","N","P","Q","R","S","T","U","V","W","X","Y","Z"), col=c("#771155", "#AA4488", "#CC99BB", "#114477", "#4477AA", "#77AADD", "#117777", "#44AAAA", "#77CCCC", "#117744", "#44AA77", "#88CCAA", "#777711", "#AAAA44", "#DDDD77", "#774411", "#AA7744", "#DDAA77", "#771122", "#AA4455", "#DD7788","orange","cyan","violet"))
final=a1
heightparam=max(((length(final$clade))*0.435)+1.70,14)
final$rplen=(final$unalnend - final$unalnstart ) + 1
aas=data.frame(unique(as.data.frame(strsplit(paste(final$rpt,collapse=""),split="")))[,1])
colnames(aas)=c("aa")
newcols=merge(aas,colpal,by="aa")
as.data.frame(unique(final$species))-> species
colnames(species)="spnames"
jpeg(paste('Repeatplot_for_figure3a.jpeg',sep=''),width=38,height=heightparam,units="in",res=300)
par(mai=c(1,0.5,0,0),oma=c(0.5,0.2,0,0.2),xpd=T)
###Plotting the rectangular boxes on the right side of the plot
plot(1, type="n", xlab="", ylab="", xlim=c(0, 126), ylim=c(0, 2*length(unique(final$species))),axes=F)
for(j in seq(0,length(unique(final$species))-1,1)){
y1=(2*j)-0.5
y2=(2*j)+0.5
rect(20,y1,120,y2)}
###Printing species names
for(j in seq(0,length(unique(final$species))-1,1)){
x1=15
y1=(2*j)+0.3
legend(x1,y1,legend=gsub("_"," ",as.character(species[j+1,1])),text.font=3,cex=1.75,adj=c(1,0),bty="n")}
###printing the gene name on the right side
for(j in seq(0,length(unique(final$species))-1,1)){
x1=120.2
y1=(2*j)+0.5
gene=as.character(unique(final[final$species==as.character(species[j+1,1]),"gene"]))
legend(x1,y1,legend=gene,text.font=3,cex=1.75,bty="n")}

###Plotting the repeats at their specific coordinates
for (z in 1:dim(final)[1]){
b1=final[z,]
spnaam=b1[1,"species"]
###get the number at which the species is written
j=which(species$spnames==spnaam)
x1=20 + (b1$alnstart/b1$alnlength)*100
x2=20 + ((b1$alnstart + b1$rplen)/b1$alnlength)*100
s=as.character(b1$rpt)
#print(s)
y1=((2*j)-0.5)-2
y2=((2*j)+0.5)-2
if(nchar(s)>4){
for(i in 1:nchar(s)){
if(i<=nchar(s)-1){
aanow=data.frame(strsplit(s,split=""))[i,]
meracol=newcols[newcols$aa==aanow,2]
rect(x1,y1,x2,y2,brder="transparent",col=meracol,lty="dashed",density=30,angle=45*i)}
else {aanow=data.frame(strsplit(s,split=""))[5,]
meracol=newcols[newcols$aa==aanow,2]
rect(x1,y1,x2,y2,border=meracol,lwd=3)
}
}
} else {for(i in 1:nchar(s)){
aanow=data.frame(strsplit(s,split=""))[i,]
meracol=newcols[newcols$aa==aanow,2]
rect(x1,y1,x2,y2,border="transparent",col=meracol,lty="dashed",density=30,angle=45*i)
}
}
rplabel=paste(b1$rpt,' (',b1$rplen,') ',sep='')
text((x1+x2)/2,y2+0.3,labels=rplabel,cex=1.1)
}
ld=data.frame(unique(as.data.frame(strsplit(paste(final$rpt,collapse=""),split="")))[,1])
colnames(ld)=c("aa")
aminocol<-merge(ld,colpal,by="aa")
legend("bottomright",legend=aminocol$aa,col=aminocol$col,horiz=T,fill=aminocol$col,inset=c(0.042,-0.06),bty="n",cex=2)
mtext('Occurrence of multiple repeats in immune genes across different species in different clade',side=3,cex=2,adj=0.5,outer=T,line=-2)
dev.off()
