library("VennDiagram") 
immune_genes_with_repeats=33876
positively_selected_immune_genes=36615
positively_selected_genes_w_rpt=2223
jpeg("Fig3c_positively_selected_lineage.jpeg",width=15,height=15,units="in",res=300)
grid.newpage()
draw.pairwise.venn(area1=immune_genes_with_repeats,area2=positively_selected_immune_genes,cross.area=positively_selected_genes_w_rpt,col=c("dodgerblue","green4"),fill=c("dodgerblue","green4"), category=c("Lineages with repeats","Positively selected lineages"),lty="blank",cex=2,cat.cex=1.5,cat.pos=c(-180,-0))
dev.off()

