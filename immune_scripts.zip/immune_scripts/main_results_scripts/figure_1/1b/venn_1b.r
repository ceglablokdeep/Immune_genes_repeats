library("VennDiagram")
adapt=722
innate=922
rpts=823
adp_n_innate=255
adp_n_rpt=141
innate_n_rpt=198
all=47

jpeg("Fig1b_venn_diagram.jpeg",width=15,height=15,units="in",res=300)
grid.newpage()
draw.triple.venn(area1=adapt,area2=innate,area3=rpts,n12=adp_n_innate,n23=innate_n_rpt,n13=adp_n_rpt,n123=all,cross.area=overlap,category=c("Adaptive immune response genes","Innate immune response genes","Immune system process genes having repeats"),fill=c("dodgerblue","green4","orchid"),lty="blank",cex=2,cat.cex=1.5,cat.pos=c(-30,30,-180))
dev.off()

