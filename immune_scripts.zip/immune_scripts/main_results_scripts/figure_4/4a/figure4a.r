a=read.table("immune_coordinates_gc_compiled")
jpeg("fig4a_rptlen_gene_len.jpeg",width=20,height=11.5,units="in",res=300)
plot(a$V6-a$V5,a$V10,pch=ifelse((a$V10<10000 & (a$V6-a$V5)<750),1,20),cex=ifelse((a$V10<10000 & (a$V6-a$V5)<750),0.5,1.5),col=ifelse((a$V10<10000 & (a$V6-a$V5)<750),"grey","blue"),main="Repeat length change with gene length change",xlab="Repeat length (nucleotides)",ylab="Gene length (nucleotides)",cex.axis=1.5,cex.lab=1.2)
b=a[a$V10>10000 | (a$V6-a$V5)>750,]
unique(b$V2)
##This gives 11 unique genes
d=a[a$V2=="HRG",c(1:8,10)]
points(d$V6-d$V5,d$V10,col="purple",cex=1.5,pch=19)
d=a[a$V2=="KMT2A",c(1:8,10)]
d1=d[d$V4=="S"||d$V4=="AGS",] 
#This gene has many non-orthologous repeats in different clades, we have subsetted only the orthologous repeats
points(d1$V6-d1$V5,d1$V10,col="maroon",cex=1.5,pch=19)
d=a[a$V2=="LRP1",c(1:8,10)]
##LRP1 has two distinct LRRs, one at beginning and one at end of the gene. So, we have to do a coordinate based search and use two different pch of same color to represent distinct repeats of same gene
d1=d[d$V6<500,]
points(d1$V6-d1$V5,d1$V10,col="lightpink",cex=1.5,pch=19)
d2=d[d$V6>500,]
points(d2$V6-d2$V5,d2$V10,col="lightpink",cex=1.5,pch=21,bg="lightpink2",lwd=2)
d=a[a$V2=="LYST",c(1:8,10)]
##LYST also has two repeats, but the second repeat is only in one clade. So we use only the first repeat which has orthologs across multiple clades
d1=d[d$V5<300,]
points(d1$V6-d1$V5,d1$V10,col="burlywood3",cex=1.5,pch=19)
##PKHD1L1 has some repeat in initial in Artiodactyla only, we removed it
d=a[a$V2=="PKHD1L1",c(1:8,10)]
d1=d[d$V5>12000,]
points(d1$V6-d1$V5,d1$V10,col="chartreuse3",cex=1.5,pch=19)
#####PRG4 has one repeat inside another repeat, and one is far away from others
d=a[a$V2=="PRG4",c(1:8,10)]
d1=d[d$V7<600,]
points(d1$V6-d1$V5,d1$V10,col="deepskyblue3",cex=1.5,pch=19)
d2=d[d$V5>500,]
points(d2$V6-d2$V5,d2$V10,col="deepskyblue3",cex=1.5,pch=21,bg="deepskyblue2",lwd=2)
d=a[a$V2=="RNF213",c(1:8,10)]
###RNF213 has clade specific repeats but we are selecting the repeats which are orthologous across different clades
d1=d[d$V4=="K"|d$V4=="KR",]
points(d1$V6-d1$V5,d1$V10,col="tan2",cex=1.5,pch=19)
legend(x=2550,y=15800, legend = c("HRG", "KMT2A","LRP1","LYST","PKHD1L1","PRG4","RNF213","outliers"), col=c("purple" ,"maroon","lightpink","burlywood3","chartreuse3","deepskyblue3","tan2","blue"), pt.cex = 3, cex = 1.5,  horiz = F,box.lwd = 0,box.col = "white",bg = "white",pch=19,title="Genes",text.font=c(rep(3,7),1))
dev.off()
