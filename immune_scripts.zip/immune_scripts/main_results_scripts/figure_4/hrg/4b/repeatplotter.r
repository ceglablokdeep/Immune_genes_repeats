####This script will plot everything
args = commandArgs(trailingOnly=TRUE)
if (length(args)<4) {
  stop("Please provide arguments like Rscript repeatplotter.r inputfile treefile cladename genename", call.=FALSE)
}
library(ape)
library(stringr)
library(TreeTools)
library(tidytree)
a1=read.table(args[1])
t1=read.tree(args[2])
colnames(a1)=c("clade","gene","species","rpt","unalnstart","unalnend","alnstart","alnend","alnlength")
clade=tolower(args[3])
cname=str_to_title(clade)
gene=toupper(args[4])
colpal=data.frame(aa = c("A","B","C","D","E","F","G","H","I","K","L","M","N","P","Q","R","S","T","U","V","W","X","Y","Z"), col=c("#771155", "#AA4488", "#CC99BB", "#114477", "#4477AA", "#77AADD", "#117777", "#44AAAA", "#77CCCC", "#117744", "#44AA77", "#88CCAA", "#777711", "#AAAA44", "#DDDD77", "#774411", "#AA7744", "#DDAA77", "#771122", "#AA4455", "#DD7788","orange","cyan","violet"))
if( any(a1$gene==gene) && dim(a1[a1$gene==gene,])[1] > 3 && any(a1$clade==clade) && dim(a1[a1$clade==clade,])[1] > 3 |any(a1$gene==gene) && dim(a1[a1$gene==gene,])[1] > 3 && cname=="All") {
if(cname=="All"){a=a1} else {
a<-a1[a1$clade==clade & a1$gene==gene,]}
final=a
t<-keep.tip(t1,unique(a$species))
pt=Preorder(t)
heightparam=max(((length(t$tip.label))*0.435)+1.70,14)
species=as.data.frame(t$tip.label)
colnames(species)=c("spnames")
final$rplen=(final$unalnend - final$unalnstart ) + 1
aas=data.frame(unique(as.data.frame(strsplit(paste(final$rpt,collapse=""),split="")))[,1])
colnames(aas)=c("aa")
newcols=merge(aas,colpal,by="aa")
jpeg(paste('Repeatplot_for_',gene,'_in_',cname,'repeats.jpeg',sep=''),width=28,height=heightparam,units="in",res=300)
par(mai=c(0.4,0,0.4,0),oma=c(0,0.4,0,0.2),xpd=T)
layout(matrix(c(1,2,2,2),nrow=1,byrow=T))
###Firstly, plotting the species tree for the gene
phylolim=max(((length(t$tip.label))/5) + 6,14)
plot.phylo(t,use.edge.length=F,node.depth=2,label.offset=0.1,x.lim=phylolim,cex=1.5)
ymax=2*length(t$tip.label)
plot(1, type="n", xlab="", ylab="", xlim=c(0, max(final$alnlength)), ylim=c(0, ymax-2),axes=F)
###Plotting the recatangular boxes on the right side of the plot
for(j in seq(0,length(t$tip.label)-1,1)){
y1=(2*j)-0.5
y2=(2*j)+0.5
rect(0,y1,max(final$alnlength),y2)}
###Plotting the repeats at their specific coordinates
for (z in 1:dim(final)[1]){
b1=final[z,]
spnaam=b1[1,"species"]
###get the number at which the species is written
j=which(species$spnames==spnaam)
x1=b1$alnstart
x2=b1$alnstart + b1$rplen
s=as.character(b1$rpt)
#print(s)
y1=((2*j)-0.5)-2
y2=((2*j)+0.5)-2
if(nchar(s)>4){
for(i in 1:nchar(s)){
if(i<=nchar(s)-1){
aanow=data.frame(strsplit(s,split=""))[i,]
meracol=newcols[newcols$aa==aanow,2]
rect(x1,y1,x2,y2,brder="transparent",col=meracol,lty="dashed",density=30,angle=45*i)}
else {aanow=data.frame(strsplit(s,split=""))[5,]
meracol=newcols[newcols$aa==aanow,2]
rect(x1,y1,x2,y2,border=meracol,lwd=3)
}
}
} else {for(i in 1:nchar(s)){
aanow=data.frame(strsplit(s,split=""))[i,]
meracol=newcols[newcols$aa==aanow,2]
rect(x1,y1,x2,y2,border="transparent",col=meracol,lty="dashed",density=30,angle=45*i)
}
}
rplabel=paste(b1$rpt,' (',b1$rplen,') ',sep='')
text((x1+x2)/2,y2+0.3,labels=rplabel)
}
ld=data.frame(unique(as.data.frame(strsplit(paste(final$rpt,collapse=""),split="")))[,1])
colnames(ld)=c("aa")
aminocol<-merge(ld,colpal,by="aa")
legend("bottomright",legend=aminocol$aa,col=aminocol$col,horiz=T,fill=aminocol$col,inset=c(0.042,-0.01),bty="n",cex=2)
genenm=final$gene[1]
ti=substitute('Repeat length distribution of'~italic(genenaam)~'gene across different species in'~cladename~'clade',list(genenaam=genenm,cladename=cname))
mtext(ti,side=3,cex=2,adj=0.5,outer=T,line=-4)
dev.off()
}else {
print("Either the clade/gene name is missing/wrong or number of species < 4 or gene is missing in gene_length file")
break }
