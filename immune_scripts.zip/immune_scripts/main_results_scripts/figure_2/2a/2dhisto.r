M=read.table("immune_coordinates_gc_compiled",header=F)
colnames(M)=c("Clade","Gene","Species","Repeat","start_unaln","end_unaln","start_aln","end_aln","aln_length_gene","unaln_cds_length","gc_percent")
M$end_unaln-M$start_unaln->M$replen_un
library(ggplot2)
M$start_unaln/M$unaln_cds_length->M$relative_start
M$end_unaln/M$unaln_cds_length->M$relative_end
jpeg("gc_relative_pos_fig1d.jpeg",,width=28,height=18,units="in",res=300)
ggplot(M, aes(y=gc_percent, x=relative_end) ) + geom_bin2d(bins = 9) + scale_fill_continuous(type = "viridis") + theme_bw() + xlab("Relative position along the gene") + ylab("GC percentage")+ theme(axis.text = element_text(size = 20)) + theme(axis.title = element_text(size = 20))
dev.off()
