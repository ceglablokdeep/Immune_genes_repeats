library(phytools)
t1=read.tree("amphibia.nwk")
a=read.table("amphibia_expan_contract")
a$V4=a$V2/(a$V2+a$V3)
t=keep.tip(t1,a$V1)
b=data.frame()
for(sp in t$tip.label){
b=rbind(b,a[a$V1==sp,])}
rownames(b)=b$V1
b$V5=paste("(",b$V2,",",b$V3,")",sep="")
jpeg("amphibia_expan_con_pie.jpeg",width=20,height=20,units="in",res=300)
plot.phylo(t,use.edge.length=F,node.depth=2,label.offset=2.2,x.lim=30,cex=1.5,edge.width=2.5,main="Frequency of expanded and contracted genes in amphibia clade")
tiplabels(pie=b$V4,piecol=c("red","blue"),cex=0.6)
tiplabels(b$V5,offset=1.2,cex=1.5,frame="none")
legend(x=23,y=3, legend = c("Genes with expanded repeats", "Genes with contracted repeats"), col=c("red" , "blue"),pch = 15, pt.cex = 3, cex = 1.5,  horiz = F,box.lwd = 0,box.col = "white",bg = "white")
