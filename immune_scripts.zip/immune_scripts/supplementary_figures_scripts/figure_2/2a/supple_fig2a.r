a=read.table("numberrepeats_per_immune_gene_specieswise",header=F)
h = hist(a$V1,plot=F,breaks=0:max(a$V1))
tot=dim(a)[1]
t=paste('Total sequences: ',tot)
jpeg("repeat_distribution_number.jpeg",width=14,height=9,units="in",res=300)
plot(h$breaks[-1],h$density,type="o",ylab="Percentage",xlab="Number of repeats",main="Distribution of number of repeats in immune genes",lwd=2,col="dodgerblue3",cex.lab=1.25,cex.main=2)
text(max(h$breaks)-1,max(h$density)-5,labels=t)
dev.off()
