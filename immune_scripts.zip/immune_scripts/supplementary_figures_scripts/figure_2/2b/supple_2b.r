a=read.table("single_aa_repeat_relativelengthtogene_relativepositioningene")
a$prop[a$V4=="G"]="nonpolar_ali"
a$prop[a$V4=="A"]="nonpolar_ali"
a$prop[a$V4=="V"]="nonpolar_ali"
a$prop[a$V4=="L"]="nonpolar_ali"
a$prop[a$V4=="I"]="nonpolar_ali"
a$prop[a$V4=="M"]="nonpolar_ali"
a$prop[a$V4=="F"]="nonpolar_aro"
a$prop[a$V4=="Y"]="nonpolar_aro"
a$prop[a$V4=="W"]="nonpolar_aro"
a$prop[a$V4=="P"]="polar_uncharged"
a$prop[a$V4=="S"]="polar_uncharged"
a$prop[a$V4=="T"]="polar_uncharged"
a$prop[a$V4=="C"]="polar_uncharged"
a$prop[a$V4=="N"]="polar_uncharged"
a$prop[a$V4=="Q"]="polar_uncharged"
a$prop[a$V4=="D"]="negatively_charged"
a$prop[a$V4=="E"]="negatively_charged"
a$prop[a$V4=="R"]="positively_charged"
a$prop[a$V4=="H"]="positively_charged"
a$prop[a$V4=="K"]="positively_charged"
###################################################
#rm(f,finaldf,h,f2)
h=hist(a[a$prop=="nonpolar_aro",]$V6,plot=F,breaks=seq(from=0,to=100,by=10))
h$counts=h$counts/sum(h$counts)
f=data.frame(h$breaks[-1],h$counts)
colnames(f)=c("intervals","nonpolar_aro")
h=hist(a[a$prop=="nonpolar_ali",]$V6,plot=F,breaks=seq(from=0,to=100,by=10))
h$counts=h$counts/sum(h$counts)
f2=data.frame(h$breaks[-1],h$counts)
colnames(f2)=c("intervals","nonpolar_ali")
finaldf=merge(f,f2,by="intervals")
h=hist(a[a$prop=="polar_uncharged",]$V6,plot=F,breaks=seq(from=0,to=100,by=10))
h$counts=h$counts/sum(h$counts)
f2=data.frame(h$breaks[-1],h$counts)
colnames(f2)=c("intervals","polar_uncharged")
finaldf=merge(finaldf,f2,by="intervals")
h=hist(a[a$prop=="negatively_charged",]$V6,plot=F,breaks=seq(from=0,to=100,by=10))
h$counts=h$counts/sum(h$counts)
f2=data.frame(h$breaks[-1],h$counts)
colnames(f2)=c("intervals","negatively_charged")
finaldf=merge(finaldf,f2,by="intervals")
h=hist(a[a$prop=="positively_charged",]$V6,plot=F,breaks=seq(from=0,to=100,by=10))
h$counts=h$counts/sum(h$counts)
f2=data.frame(h$breaks[-1],h$counts)
colnames(f2)=c("intervals","positively_charged")
finaldf=merge(finaldf,f2,by="intervals")
write.table(finaldf,file='relativeposition_aatype.txt',quote=F,col.names=T,row.names=F,sep="\t")
jpeg("repeat_distribution_by_properties_gene_position.jpeg",width=14,height=9,units="in",res=300)
plot(2,xlim=c(0,100),ylim=c(0,1),xlab="",ylab="",xaxt="n",main="Frequency of repeats along the gene",cex.axis=1.5,cex.main=1.5)
axis(1, at=seq(from=5,to=95,by=10), labels=c("0-10", "10-20", "20-30", "30-40", "40-50", "50-60", "60-70", "70-80", "80-90", "90-100"),tick=F)
colpal=c("brown","purple","blue","green","violet")
for(r in 1:dim(finaldf)[1]){
r1=finaldf[r,]
x1=r1[1,1]-10
for(c in 2:dim(r1)[2]){
x2=x1+2
rect(x1,0,x2,r1[1,c],col=colpal[c-1])
x1=x1+2}
}
title(ylab="Proportion", line=2.5, cex.lab=1.5)        
title(xlab="Relative positive in a gene", line=3, cex.lab=1.5)
haro=paste("Nonpolar aromatic (",dim(a[a$prop=="nonpolar_aro",])[1],")")
hali=paste("Nonpolar aliphatic (",dim(a[a$prop=="nonpolar_ali",])[1],")")
hpol=paste("Polar uncharged (",dim(a[a$prop=="polar_uncharged",])[1],")")
haci=paste("Negatively charged (",dim(a[a$prop=="negatively_charged",])[1],")")
hbas=paste("Positively charged (",dim(a[a$prop=="positively_charged",])[1],")")
legend(55,0.95,box.col="white",bg ="white", box.lwd =0,legend=c(haro, hali,hpol,haci,hbas),fill = colpal,cex=2)
dev.off()

